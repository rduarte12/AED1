#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    printf("%c\n", 'A');
    printf("%d\n", 'A');

    int number = 'A';
    printf("%d\n", number);
}